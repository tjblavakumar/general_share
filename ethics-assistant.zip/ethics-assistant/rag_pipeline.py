import json
import boto3
from scraper import EthicsPageScraper
from embedding_service import EmbeddingService
from vector_store import EthicsVectorStore
from holdings_service import HoldingsService
from audit_logger import AuditLogger
from config import AWS_REGION, LLM_MODEL_ID, FALLBACK_MESSAGE


class EthicsRAGPipeline:
    def __init__(self):
        self.scraper = EthicsPageScraper()
        self.embedding_service = EmbeddingService()
        self.vector_store = EthicsVectorStore()
        self.holdings_service = HoldingsService()
        self.audit_logger = AuditLogger()
        self.bedrock_client = boto3.Session(region_name=AWS_REGION).client('bedrock-runtime')
        self.ingested = False

    def ingest(self) -> dict:
        pages = self.scraper.scrape_all()
        chunks = self.scraper.chunk_pages(pages)
        embeddings = self.embedding_service.embed_batch([c["content"] for c in chunks])
        self.vector_store.clear()
        self.vector_store.add_documents(chunks, embeddings)
        self.ingested = True
        return {
            "scrape_status": self.scraper.get_scrape_status(),
            "chunks_indexed": len(chunks)
        }

    def query(self, question: str, persona: str) -> dict:
        # Step 1 — Check Structured Data
        holdings_result = self.holdings_service.check_restriction(question, persona)

        # Step 2 — Consult Vector Store
        try:
            query_embedding = self.embedding_service.embed_text(question)
            vector_results = self.vector_store.search(query_embedding, top_k=5)
        except Exception as e:
            print(f"Vector search error: {e}")
            vector_results = []

        # Fallback — if no structured data AND no vector results, skip Claude
        if not holdings_result.get("found") and not vector_results:
            self.audit_logger.log_query(persona, question, "Unknown", [], FALLBACK_MESSAGE)
            return {
                "answer": FALLBACK_MESSAGE,
                "determination": "Unknown",
                "holdings_result": None,
                "vector_results": [],
                "sources": []
            }

        # Step 3 — Synthesize with Claude
        system_prompt = (
            "You are an Ethics & Conduct advisor for the Federal Reserve Bank of San Francisco (FRBSF). "
            "You provide authoritative guidance on employee ethics, conduct, and investment restrictions.\n\n"
            "RULES:\n"
            "1. Always provide a clear determination: \"Permitted\", \"Prohibited\", or \"Requires Approval\".\n"
            "2. Always cite your source — either quote the ethics document verbatim or reference the specific regulation.\n"
            "3. If the information is persona-specific, clearly state how the rule differs by role.\n"
            f"4. If you cannot find a clear answer in the provided context, respond with: \"{FALLBACK_MESSAGE}\"\n"
            "5. Always end with: \"Disclaimer: This is an AI-assisted tool. For binding guidance, consult a Deputy Ethics Officer.\""
        )

        if holdings_result.get("found"):
            holdings_context = json.dumps(holdings_result, indent=2)
        else:
            holdings_context = "No matching holding found in the prohibited holdings database."

        if vector_results:
            vector_context_parts = []
            for vr in vector_results:
                source_url = vr["metadata"].get("source_url", "Unknown")
                vector_context_parts.append(
                    f"[Source: {source_url}]\n{vr['content']}"
                )
            vector_context = "\n\n".join(vector_context_parts)
        else:
            vector_context = "No relevant ethics document sections found."

        user_message = (
            f"User Persona: {persona}\n"
            f"User Question: {question}\n\n"
            f"--- STRUCTURED DATA (Prohibited Holdings Check) ---\n"
            f"{holdings_context}\n\n"
            f"--- ETHICS DOCUMENT CONTEXT ---\n"
            f"{vector_context}\n\n"
            f"Based on the above context, provide your determination and explanation for this {persona}."
        )

        try:
            response = self.bedrock_client.invoke_model(
                modelId=LLM_MODEL_ID,
                body=json.dumps({
                    "anthropic_version": "bedrock-2023-05-31",
                    "max_tokens": 2000,
                    "temperature": 0.1,
                    "system": system_prompt,
                    "messages": [{"role": "user", "content": user_message}]
                })
            )
            response_body = json.loads(response['body'].read())
            answer = response_body['content'][0]['text']
        except Exception as e:
            print(f"Claude invocation error: {e}")
            answer = f"Error generating response: {e}"

        # Step 4 — Extract determination
        determination = "See Response"
        if holdings_result.get("found"):
            determination = holdings_result.get("determination", "See Response")
        else:
            first_lines = answer[:500].lower()
            if "prohibited" in first_lines:
                determination = "Prohibited"
            elif "requires approval" in first_lines:
                determination = "Requires Approval"
            elif "permitted" in first_lines:
                determination = "Permitted"

        # Step 5 — Build sources list
        sources = []
        if holdings_result.get("found"):
            sources.append("Prohibited Holdings Database")
        for vr in vector_results:
            source_url = vr["metadata"].get("source_url", "")
            if source_url and source_url not in sources:
                sources.append(source_url)

        # Step 6 — Audit Log
        self.audit_logger.log_query(persona, question, determination, sources, answer)

        # Step 7 — Return
        return {
            "answer": answer,
            "determination": determination,
            "holdings_result": holdings_result if holdings_result.get("found") else None,
            "vector_results": vector_results,
            "sources": sources
        }

    def get_scrape_status(self) -> dict:
        return self.scraper.get_scrape_status()

    def get_stats(self) -> dict:
        return self.vector_store.get_stats()
