import chromadb
from config import CHROMA_PERSIST_DIR, CHROMA_COLLECTION_NAME, SIMILARITY_THRESHOLD


class EthicsVectorStore:
    def __init__(self):
        self.client = chromadb.PersistentClient(path=CHROMA_PERSIST_DIR)
        self.collection = self.client.get_or_create_collection(
            name=CHROMA_COLLECTION_NAME,
            metadata={"hnsw:space": "cosine"}
        )

    def add_documents(self, chunks, embeddings):
        ids = [chunk["id"] for chunk in chunks]
        documents = [chunk["content"] for chunk in chunks]
        metadatas = [chunk["metadata"] for chunk in chunks]

        self.collection.upsert(
            ids=ids,
            embeddings=embeddings,
            documents=documents,
            metadatas=metadatas
        )

    def search(self, query_embedding, top_k=5) -> list:
        results = self.collection.query(
            query_embeddings=[query_embedding],
            n_results=top_k,
            include=["documents", "metadatas", "distances"]
        )

        filtered = []
        if results and results["documents"] and results["documents"][0]:
            for i, doc in enumerate(results["documents"][0]):
                distance = results["distances"][0][i]
                similarity = 1 - (distance / 2)
                if similarity >= SIMILARITY_THRESHOLD:
                    filtered.append({
                        "content": doc,
                        "metadata": results["metadatas"][0][i],
                        "similarity": similarity
                    })

        return filtered

    def clear(self):
        self.client.delete_collection(CHROMA_COLLECTION_NAME)
        self.collection = self.client.get_or_create_collection(
            name=CHROMA_COLLECTION_NAME,
            metadata={"hnsw:space": "cosine"}
        )

    def get_stats(self) -> dict:
        return {"total_documents": self.collection.count()}
