# FRBSF Ethics & Conduct AI Assistant

AI-powered assistant that answers employee ethics and conduct questions using a Hybrid RAG architecture — combining structured prohibited holdings data with unstructured ethics policy documents.

## Prerequisites

- Python 3.9+
- AWS account with Bedrock access enabled for:
  - `amazon.titan-embed-text-v1` (embeddings)
  - `anthropic.claude-3-sonnet-20240229-v1:0` (generation)

## Setup

```bash
# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Configure AWS credentials
cp .env.example .env
# Edit .env with your AWS credentials

# Run the app
streamlit run app.py
```

## Architecture

```
User Question + Persona
        │
        ▼
┌─────────────────┐
│  Holdings Check  │ ← prohibited_holdings.json
│  (Structured)    │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Vector Search   │ ← ChromaDB (scraped ethics docs)
│  (Unstructured)  │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Claude Sonnet   │ ← Synthesize answer with determination
│  (Generation)    │
└────────┬────────┘
         │
         ▼
   Response with
   Determination + Citation + Disclaimer
```

## Sample Questions

- "Can I buy Bank of America stock?" (tests structured lookup + persona logic)
- "What are the gift acceptance rules?" (tests vector store RAG)
- "Is VTI permitted for all employees?" (tests permitted holding)
- "Can I hold Goldman Sachs stock?" (tests requires_approval flow)
- "What is the recusal policy?" (tests vector store RAG)

## Credential Options

- **Environment Variables:** Set `AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, `AWS_SESSION_TOKEN`, `AWS_REGION` in `.env`
- **AWS CLI Profile:** Run `aws configure` or `aws sso login`
- **IAM Role (EC2):** Attach role with `bedrock:InvokeModel` permission — no code changes needed

> **Note:** Temporary credentials (session tokens) expire after 1-12 hours. Refresh before demos.
