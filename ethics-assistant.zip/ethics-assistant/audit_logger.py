import json
import sqlite3
from datetime import datetime
from config import AUDIT_DB


class AuditLogger:
    def __init__(self):
        self.conn = sqlite3.connect(AUDIT_DB, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self._create_table()

    def _create_table(self):
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS query_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT,
                persona TEXT,
                query_text TEXT,
                determination TEXT,
                sources_used TEXT,
                response_summary TEXT
            )
        """)
        self.conn.commit()

    def log_query(self, persona, query, determination, sources, response):
        self.conn.execute(
            """INSERT INTO query_log
               (timestamp, persona, query_text, determination, sources_used, response_summary)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (
                datetime.utcnow().isoformat(),
                persona,
                query,
                determination,
                json.dumps(sources),
                response[:500]
            )
        )
        self.conn.commit()

    def get_recent_logs(self, limit=50) -> list:
        cursor = self.conn.execute(
            "SELECT * FROM query_log ORDER BY id DESC LIMIT ?",
            (limit,)
        )
        rows = cursor.fetchall()
        return [dict(row) for row in rows]
