import hashlib
import requests
from bs4 import BeautifulSoup
from datetime import datetime
from config import ETHICS_URLS, CHUNK_SIZE, CHUNK_OVERLAP


class EthicsPageScraper:
    def __init__(self):
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        self.scrape_status = {}

    def scrape_all(self) -> list:
        pages = []
        for url in ETHICS_URLS:
            try:
                response = requests.get(url, headers=self.headers, timeout=30)
                response.raise_for_status()

                soup = BeautifulSoup(response.text, 'lxml')

                for tag in soup.find_all(['nav', 'footer', 'script', 'style', 'header', 'aside']):
                    tag.decompose()

                main = (
                    soup.find('main')
                    or soup.find('article')
                    or soup.find('div', role='main')
                    or soup.find('body')
                )

                if main:
                    text = main.get_text(separator='\n', strip=True)
                    lines = text.split('\n')
                    cleaned = '\n'.join(line.strip() for line in lines if line.strip())
                else:
                    cleaned = ""

                pages.append({
                    "url": url,
                    "title": soup.title.string if soup.title else url,
                    "content": cleaned,
                    "scraped_at": datetime.utcnow().isoformat()
                })

                self.scrape_status[url] = {
                    "success": True,
                    "timestamp": datetime.utcnow().isoformat()
                }

            except Exception as e:
                print(f"Error scraping {url}: {e}")
                self.scrape_status[url] = {
                    "success": False,
                    "error": str(e),
                    "timestamp": datetime.utcnow().isoformat()
                }
                continue

        return pages

    def chunk_pages(self, pages: list) -> list:
        chunks = []
        for page in pages:
            content = page["content"]
            url = page["url"]
            title = page.get("title", "")
            scraped_at = page.get("scraped_at", "")

            start = 0
            chunk_index = 0
            while start < len(content):
                end = start + CHUNK_SIZE
                chunk_text = content[start:end]

                chunk_id = hashlib.md5(f"{url}_{chunk_index}".encode()).hexdigest()

                chunks.append({
                    "id": chunk_id,
                    "content": chunk_text,
                    "metadata": {
                        "source_url": url,
                        "title": title,
                        "chunk_index": chunk_index,
                        "scraped_at": scraped_at
                    }
                })

                start += CHUNK_SIZE - CHUNK_OVERLAP
                chunk_index += 1

        return chunks

    def get_scrape_status(self) -> dict:
        return self.scrape_status
