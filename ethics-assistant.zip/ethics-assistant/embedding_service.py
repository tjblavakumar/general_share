import json
import time
import boto3
from config import AWS_REGION, EMBEDDING_MODEL_ID, EMBEDDING_DIMENSION


class EmbeddingService:
    def __init__(self):
        self.available = False
        try:
            session = boto3.Session(region_name=AWS_REGION)
            self.bedrock_runtime = session.client('bedrock-runtime')
            self.bedrock_runtime.invoke_model(
                modelId=EMBEDDING_MODEL_ID,
                body=json.dumps({"inputText": "test"})
            )
            self.available = True
            print("Embedding service initialized successfully.")
        except Exception as e:
            print(f"Embedding service unavailable: {e}")
            self.available = False

    def embed_text(self, text: str) -> list:
        input_text = text[:8000]
        response = self.bedrock_runtime.invoke_model(
            modelId=EMBEDDING_MODEL_ID,
            body=json.dumps({"inputText": input_text})
        )
        response_body = json.loads(response['body'].read())
        return response_body['embedding']

    def embed_batch(self, texts: list) -> list:
        embeddings = []
        for text in texts:
            try:
                embedding = self.embed_text(text)
                embeddings.append(embedding)
            except Exception as e:
                print(f"Error embedding text: {e}")
                embeddings.append([0.0] * EMBEDDING_DIMENSION)
            time.sleep(0.1)
        return embeddings
