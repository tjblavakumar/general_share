import os
from dotenv import load_dotenv

load_dotenv()

# AWS
AWS_REGION = os.getenv('AWS_REGION', 'us-east-1')

# Model IDs
EMBEDDING_MODEL_ID = "amazon.titan-embed-text-v1"
EMBEDDING_DIMENSION = 1536
LLM_MODEL_ID = "anthropic.claude-3-sonnet-20240229-v1:0"

# Chunking
CHUNK_SIZE = 500
CHUNK_OVERLAP = 100

# Vector Store
SIMILARITY_THRESHOLD = 0.3
CHROMA_COLLECTION_NAME = "ethics_documents"
CHROMA_PERSIST_DIR = "./chroma_db"

# Data
HOLDINGS_FILE = os.path.join(os.path.dirname(__file__), "data", "prohibited_holdings.json")
AUDIT_DB = "audit_log.db"

# Scraping targets
ETHICS_URLS = [
    "https://www.federalreserve.gov/aboutthefed/ethics-values.htm",
    "https://www.frbsf.org/about-us/governance/ethics-conduct/"
]

# Personas
PERSONAS = ["General Employee", "Senior Official/Director", "Bank Examiner"]

# Fallback
FALLBACK_MESSAGE = "This query is not covered by public documentation. Please refer to a Deputy Ethics Officer."
