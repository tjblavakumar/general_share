import streamlit as st
from rag_pipeline import EthicsRAGPipeline
from config import PERSONAS, FALLBACK_MESSAGE
import pandas as pd

st.set_page_config(
    page_title="FRBSF Ethics & Conduct Assistant",
    page_icon="\u2696\ufe0f",
    layout="wide"
)

# Session state initialization
if "pipeline" not in st.session_state:
    st.session_state.pipeline = EthicsRAGPipeline()
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []
if "ingested" not in st.session_state:
    st.session_state.ingested = False

# Sidebar
with st.sidebar:
    st.title("\u2696\ufe0f FRBSF Ethics Assistant")
    st.markdown("---")

    # Persona selector
    persona = st.selectbox("Select Your Role", PERSONAS, index=0)
    st.session_state.persona = persona

    st.markdown("---")

    # Knowledge Base section
    st.subheader("Knowledge Base")

    if st.button("\U0001f504 Refresh Knowledge Base"):
        with st.spinner("Scraping ethics pages and building index..."):
            result = st.session_state.pipeline.ingest()
            st.session_state.ingested = True
            for url, status in result["scrape_status"].items():
                if status["success"]:
                    st.success(f"\u2705 {url}")
                else:
                    st.error(f"\u274c {url}: {status['error']}")
            st.info(f"Indexed {result['chunks_indexed']} chunks")

    # Show stats
    if st.session_state.ingested:
        stats = st.session_state.pipeline.get_stats()
        st.metric("Indexed Chunks", stats["total_documents"])

    st.markdown("---")

    # Recent audit log
    st.subheader("Recent Queries")
    logs = st.session_state.pipeline.audit_logger.get_recent_logs(limit=10)
    if logs:
        df = pd.DataFrame(logs)
        st.dataframe(df, use_container_width=True, hide_index=True)
    else:
        st.caption("No queries yet.")

# Main chat area
st.title("Ethics & Conduct Assistant")
st.caption("Ask questions about FRBSF ethics policies, investment restrictions, and conduct guidelines.")

# Warning if not ingested
if not st.session_state.ingested:
    st.warning(
        "\u26a0\ufe0f Knowledge base not loaded. Click 'Refresh Knowledge Base' in the sidebar "
        "to index ethics documents. You can still ask about specific holdings."
    )

# Show scrape warnings if any URL failed
scrape_status = st.session_state.pipeline.get_scrape_status()
for url, status in scrape_status.items():
    if not status.get("success", True):
        st.warning(f"\u26a0\ufe0f Could not load: {url} \u2014 Results may be incomplete.")

# Display chat history
for msg in st.session_state.chat_history:
    with st.chat_message(msg["role"]):
        if msg["role"] == "assistant" and msg.get("metadata"):
            meta = msg["metadata"]
            det = meta.get("determination", "")
            if det == "Prohibited":
                st.error(f"\U0001f534 Determination: {det}")
            elif det == "Requires Approval":
                st.warning(f"\U0001f7e1 Determination: {det}")
            elif det == "Permitted":
                st.success(f"\U0001f7e2 Determination: {det}")

            st.markdown(msg["content"])

            if meta.get("sources"):
                with st.expander("\U0001f4c4 Sources & Citations"):
                    for src in meta["sources"]:
                        st.markdown(f"- {src}")
                    if meta.get("holdings_result"):
                        hr = meta["holdings_result"]
                        st.markdown(f"**Regulation:** {hr.get('source_regulation', 'N/A')}")
                        st.markdown(f"**Rule:** {hr.get('rule', 'N/A')}")
                        if hr.get("exemptions"):
                            st.markdown(f"**Exemptions:** {', '.join(hr['exemptions'])}")
        else:
            st.markdown(msg["content"])

# Chat input
if prompt := st.chat_input("Ask about ethics policies, investment restrictions, or conduct guidelines..."):
    # Add user message
    st.session_state.chat_history.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    # Get response
    with st.chat_message("assistant"):
        with st.spinner("Analyzing..."):
            result = st.session_state.pipeline.query(prompt, st.session_state.persona)

        det = result.get("determination", "")
        if det == "Prohibited":
            st.error(f"\U0001f534 Determination: {det}")
        elif det == "Requires Approval":
            st.warning(f"\U0001f7e1 Determination: {det}")
        elif det == "Permitted":
            st.success(f"\U0001f7e2 Determination: {det}")

        st.markdown(result["answer"])

        if result.get("sources"):
            with st.expander("\U0001f4c4 Sources & Citations"):
                for src in result["sources"]:
                    st.markdown(f"- {src}")
                if result.get("holdings_result"):
                    hr = result["holdings_result"]
                    st.markdown(f"**Regulation:** {hr.get('source_regulation', 'N/A')}")
                    st.markdown(f"**Rule:** {hr.get('rule', 'N/A')}")
                    if hr.get("exemptions"):
                        st.markdown(f"**Exemptions:** {', '.join(hr['exemptions'])}")

    # Save to history
    st.session_state.chat_history.append({
        "role": "assistant",
        "content": result["answer"],
        "metadata": {
            "determination": result.get("determination"),
            "sources": result.get("sources", []),
            "holdings_result": result.get("holdings_result")
        }
    })
