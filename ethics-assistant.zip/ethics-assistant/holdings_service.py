import json
from config import HOLDINGS_FILE


class HoldingsService:
    PERSONA_MAP = {
        "General Employee": "General Employee",
        "Senior Official/Director": "Senior Official",
        "Bank Examiner": "Bank Examiner"
    }

    def __init__(self):
        with open(HOLDINGS_FILE, 'r') as f:
            self.holdings = json.load(f)

    def lookup(self, query: str) -> dict | None:
        query_lower = query.lower()
        for holding in self.holdings:
            if (holding["ticker"].lower() in query_lower
                    or holding["entity"].lower() in query_lower):
                return holding
        return None

    def check_restriction(self, query: str, persona: str) -> dict:
        holding = self.lookup(query)
        if not holding:
            return {"found": False}

        mapped_persona = self.PERSONA_MAP.get(persona, persona)
        restricted_for = holding.get("restricted_for", [])

        if not restricted_for:
            determination = holding["status"].capitalize()
            if determination == "Requires_approval":
                determination = "Requires Approval"
        elif mapped_persona in restricted_for:
            if holding["status"] == "prohibited":
                determination = "Prohibited"
            elif holding["status"] == "requires_approval":
                determination = "Requires Approval"
            elif holding["status"] == "permitted":
                determination = "Permitted"
            else:
                determination = holding["status"].capitalize()
        else:
            determination = "Permitted"

        return {
            "found": True,
            "entity": holding["entity"],
            "ticker": holding["ticker"],
            "sector": holding["sector"],
            "determination": determination,
            "rule": holding["rule"],
            "source_regulation": holding["source_regulation"],
            "exemptions": holding.get("exemptions", []),
            "effective_date": holding.get("effective_date", ""),
            "persona_specific": len(restricted_for) > 0,
            "restricted_roles": restricted_for
        }
