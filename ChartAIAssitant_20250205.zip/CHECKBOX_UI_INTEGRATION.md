# Instructions for Checkbox UI Integration

## Changes Needed in app.py:

### 1. When showing indicator options (both initial and add_indicator):

Replace the text-based indicator list with:

```python
# Show checkbox UI
st.session_state.selected_indicators_ui = ui_helpers.display_indicator_selection_ui(
    df, 
    relevant_indicators, 
    indicator_col,
    key_prefix="initial" if not st.session_state.in_modification_mode else "add"
)
```

### 2. When user types "done" or "add these":

Check with:
```python
if ui_helpers.check_done_command(prompt):
    selected = st.session_state.selected_indicators_ui
    if selected:
        # Proceed with selected indicators
    else:
        # Show error: no indicators selected
```

### 3. Default timeline (2010M01 to 2025M01):

In parse_user_selection or when creating initial config, add:
```python
if not selection.get('selected_periods') or selection['selected_periods'] == 'all':
    selection['period_range'] = {'start': '2010m01', 'end': '2025m01'}
```

## Key Locations to Update:

1. **Initial chart creation** (line ~280): After SQL query finds indicators
2. **Add indicator modification** (line ~220): When add_indicator is detected  
3. **awaiting_indicator_selection handler** (line ~240): Check for done command
4. **awaiting_selection handler** (line ~260): Apply default timeline

The checkbox UI will persist across reruns, so users can select multiple indicators before typing "done".
