import os

# Use environment variables if set, otherwise use defaults
AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
AWS_PROFILE = os.getenv("AWS_PROFILE", "default")
MODEL_ID = os.getenv("MODEL_ID", "us.anthropic.claude-3-5-sonnet-20240620-v1:0")

DATA_FOLDER = "data"
DB_PATH = "chat_history.db"
