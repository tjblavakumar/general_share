import json
import pandas as pd

def generate_executive_summary(df, config, llm_client, model_id):
    """Generate executive summary for chart using LLM.
    
    Args:
        df: DataFrame with chart data
        config: Chart configuration
        llm_client: Bedrock client
        model_id: Model ID to use
    
    Returns:
        String with 3-4 bullet points
    """
    # Extract relevant data
    indicators = config.get('selected_indicators', [])
    period_range = config.get('period_range', {})
    chart_type = config.get('chart_type', 'line')
    aggregations = config.get('aggregations', [])
    
    # Get indicator column
    indicator_col = df.columns[1]
    
    # Collect data samples for analysis
    data_summary = []
    for indicator in indicators:
        ind_data = df[df[indicator_col] == indicator]
        if len(ind_data) > 0:
            # Get time period columns
            time_cols = df.columns[2:].tolist()
            values = []
            periods = []
            
            for col in time_cols[-20:]:  # Last 20 periods
                try:
                    val = ind_data[col].iloc[0]
                    if pd.notna(val) and val != '':
                        values.append(float(str(val).replace(',', '')))
                        periods.append(str(col))
                except:
                    pass
            
            if values:
                data_summary.append({
                    'indicator': indicator,
                    'latest_value': values[-1] if values else None,
                    'earliest_value': values[0] if values else None,
                    'max_value': max(values),
                    'min_value': min(values),
                    'avg_value': sum(values) / len(values),
                    'trend': 'increasing' if values[-1] > values[0] else 'decreasing' if values[-1] < values[0] else 'stable',
                    'sample_periods': periods[-5:],
                    'sample_values': values[-5:]
                })
    
    # Build prompt
    agg_context = ""
    if aggregations:
        agg_context = "\n\nAggregations:\n"
        for agg in aggregations:
            agg_context += f"- {agg['name']}: Sum of {', '.join(agg['indicators'])}\n"
    
    system_prompt = f"""You are an executive analyst. Generate 3-4 concise bullet points summarizing this chart for C-level executives (CEO, CIO).

Focus on:
- Key trends and patterns
- Notable anomalies or outliers
- Business implications
- Critical insights for decision-making

Chart Configuration:
- Type: {chart_type}
- Time Range: {period_range.get('start', 'N/A')} to {period_range.get('end', 'N/A')}
- Indicators: {', '.join(indicators)}{agg_context}

Data Analysis:
{json.dumps(data_summary, indent=2)}

Return ONLY 3-4 bullet points. Each bullet should be one concise sentence.
Format: Start each point with "• " (bullet character).
Be specific with numbers and trends.
"""

    messages = [{
        "role": "user",
        "content": "Generate executive summary for this chart."
    }]
    
    body = json.dumps({
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 500,
        "system": system_prompt,
        "messages": messages,
        "temperature": 0.5
    })
    
    try:
        response = llm_client.invoke_model(modelId=model_id, body=body)
        response_body = json.loads(response['body'].read())
        content = response_body['content'][0]['text']
        return content.strip()
    except Exception as e:
        return f"• Unable to generate summary: {str(e)}"
