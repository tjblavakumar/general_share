import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import pandas as pd

def create_timeseries_chart(df, config):
    """Generate chart from time-series data structure."""
    from modules import color_palette
    
    chart_type = config['chart_type']
    indicators = config['selected_indicators']
    periods = config['selected_periods']
    
    # Get indicator column name (column 2)
    indicator_col = df.columns[1]
    
    # Filter data by selected indicators
    filtered_df = df[df[indicator_col].isin(indicators)]
    
    if len(filtered_df) == 0:
        raise ValueError(f"No data found for indicators: {indicators}")
    
    # Select time period columns
    if 'period_range' in config and config['period_range']:
        # Filter by range
        start = config['period_range'].get('start', '').upper()
        end = config['period_range'].get('end', '').upper()
        
        all_periods = df.columns[2:].tolist()
        period_cols = []
        in_range = False
        
        for col in all_periods:
            col_str = str(col).upper()
            if start in col_str:
                in_range = True
            if in_range:
                period_cols.append(col)
            if end and end in col_str:
                break
        
        if not period_cols:
            period_cols = all_periods
    elif periods == "all":
        period_cols = df.columns[2:].tolist()
    else:
        period_cols = [col for col in df.columns[2:] if str(col) in [str(p) for p in periods]]
    
    if len(period_cols) == 0:
        raise ValueError("No time period columns found")
    
    # Get colors from palette or custom colors
    if 'all_color' in config and config['all_color']:
        # All indicators use same color
        colors = [config['all_color']] * len(indicators)
    elif 'indicator_colors' in config and config['indicator_colors']:
        colors = [config['indicator_colors'].get(ind, color_palette.DEFAULT_PALETTE[i % len(color_palette.DEFAULT_PALETTE)]) 
                  for i, ind in enumerate(indicators)]
    else:
        colors = color_palette.get_colors_for_indicators(len(indicators))
    
    # Get styling options
    line_width = config.get('line_width', 3)
    marker_size = config.get('marker_size', 8)
    
    # Create chart
    fig = go.Figure()
    
    for idx, indicator in enumerate(indicators):
        indicator_data = filtered_df[filtered_df[indicator_col] == indicator]
        if len(indicator_data) == 0:
            continue
        
        # Get values from the first matching row
        values = []
        x_labels = []
        for col in period_cols:
            try:
                val = indicator_data[col].iloc[0]
                if pd.isna(val) or val == '' or val is None:
                    continue
                else:
                    numeric_val = float(str(val).replace(',', ''))
                    values.append(numeric_val)
                    x_labels.append(str(col))
            except (ValueError, IndexError, AttributeError) as e:
                continue
        
        if len(values) == 0:
            continue
        
        color = colors[idx]
        
        # Determine chart type for this indicator
        if chart_type == 'mixed' and 'indicator_chart_types' in config:
            indicator_type = config['indicator_chart_types'].get(indicator, 'line')
        else:
            indicator_type = chart_type
        
        if indicator_type == 'line':
            fig.add_trace(go.Scatter(
                x=x_labels, y=values, mode='lines+markers', 
                name=str(indicator), 
                line=dict(color=color, width=line_width),
                marker=dict(size=marker_size),
                connectgaps=False
            ))
        elif indicator_type in ['bar', 'stacked_bar']:
            fig.add_trace(go.Bar(
                x=x_labels, y=values, name=str(indicator),
                marker=dict(color=color)
            ))
    
    if chart_type == 'stacked_bar':
        fig.update_layout(barmode='stack')
    
    # Apply layout
    legend_config = {}
    if not config.get('show_legend', True):
        legend_config['showlegend'] = False
    elif config.get('legend_position'):
        pos = config['legend_position']
        legend_config['legend'] = dict(
            orientation='h' if pos in ['top', 'bottom'] else 'v',
            yanchor='top' if pos == 'top' else 'bottom' if pos == 'bottom' else 'middle',
            y=1.1 if pos == 'top' else -0.2 if pos == 'bottom' else 0.5,
            xanchor='left' if pos == 'left' else 'right' if pos == 'right' else 'center',
            x=0 if pos == 'left' else 1 if pos == 'right' else 0.5
        )
    
    fig.update_layout(
        title=config.get('title', 'Time Series Chart'),
        xaxis_title=config.get('x_label', 'Time Period'),
        yaxis_title=config.get('y_label') if config.get('y_label') else 'Value',
        showlegend=config.get('show_legend', True),
        hovermode='x unified',
        xaxis=dict(type='category'),
        **legend_config
    )
    
    return fig

def create_chart(df, config, customization=None):
    """Generate Plotly chart based on configuration."""
    chart_type = config.get('chart_type')
    x_col = config.get('x_column')
    y_cols = config.get('y_columns', [])
    title = config.get('title', 'Chart')
    x_label = config.get('x_label', x_col)
    y_label = config.get('y_label', 'Value')
    
    # Apply customization overrides
    if customization:
        title = customization.get('title', title)
        x_label = customization.get('x_label', x_label)
        y_label = customization.get('y_label', y_label)
    
    if chart_type == 'line':
        fig = go.Figure()
        for y_col in y_cols:
            fig.add_trace(go.Scatter(x=df[x_col], y=df[y_col], mode='lines+markers', name=y_col))
    
    elif chart_type == 'bar':
        fig = go.Figure()
        for y_col in y_cols:
            fig.add_trace(go.Bar(x=df[x_col], y=df[y_col], name=y_col))
    
    elif chart_type == 'pie':
        fig = go.Figure(data=[go.Pie(labels=df[x_col], values=df[y_cols[0]], name=y_cols[0])])
    
    elif chart_type == 'stacked_bar':
        fig = go.Figure()
        for y_col in y_cols:
            fig.add_trace(go.Bar(x=df[x_col], y=df[y_col], name=y_col))
        fig.update_layout(barmode='stack')
    
    elif chart_type == 'mixed':
        fig = go.Figure()
        y_types = config.get('y_types', ['line'] * len(y_cols))
        
        for y_col, y_type in zip(y_cols, y_types):
            if y_type == 'line':
                fig.add_trace(go.Scatter(x=df[x_col], y=df[y_col], mode='lines+markers', name=y_col))
            elif y_type == 'bar':
                fig.add_trace(go.Bar(x=df[x_col], y=df[y_col], name=y_col))
    
    else:
        raise ValueError(f"Unsupported chart type: {chart_type}")
    
    # Apply layout
    legend_config = {}
    if customization:
        if not customization.get('show_legend', True):
            legend_config['showlegend'] = False
        else:
            legend_config['legend'] = dict(
                orientation=customization.get('legend_orientation', 'v'),
                x=customization.get('legend_x', 1.02),
                y=customization.get('legend_y', 1)
            )
    
    fig.update_layout(
        title=title,
        xaxis_title=x_label,
        yaxis_title=y_label,
        hovermode='x unified',
        **legend_config
    )
    
    return fig
