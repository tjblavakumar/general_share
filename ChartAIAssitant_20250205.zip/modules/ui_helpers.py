import pandas as pd
import streamlit as st

def display_indicator_selection_ui(df, indicators, indicator_col, key_prefix="indicator"):
    """Display checkbox UI for indicator selection with sample data."""
    
    # Get sample time period columns (3-5 columns)
    time_cols = df.columns[2:].tolist()
    
    # Select sample columns: try to get 2020M01, 2022M01, 2024M01 or similar spread
    sample_cols = []
    target_years = ['2020M01', '2022M01', '2024M01', '2021M01', '2023M01']
    
    for target in target_years:
        for col in time_cols:
            if target.lower() in str(col).lower():
                sample_cols.append(col)
                break
        if len(sample_cols) >= 3:
            break
    
    # If not enough, just take first 3-5
    if len(sample_cols) < 3:
        sample_cols = time_cols[:min(5, len(time_cols))]
    
    st.markdown("### Select Indicators")
    st.markdown(f"**Sample data from:** {', '.join([str(c) for c in sample_cols[:5]])}")
    
    # Create table data
    table_data = []
    for idx, indicator in enumerate(indicators):
        # Get data for this indicator
        indicator_data = df[df[indicator_col] == indicator]
        
        if len(indicator_data) > 0:
            row_data = {"Indicator": indicator}
            has_data = False
            
            for col in sample_cols[:5]:
                try:
                    val = indicator_data[col].iloc[0]
                    if pd.notna(val) and val != '' and val != 0:
                        row_data[str(col)] = f"{float(val):,.2f}" if isinstance(val, (int, float)) else str(val)
                        has_data = True
                    else:
                        row_data[str(col)] = "-"
                except:
                    row_data[str(col)] = "-"
            
            row_data["has_data"] = has_data
            table_data.append(row_data)
    
    # Display with checkboxes
    selected_indicators = []
    
    for idx, row in enumerate(table_data):
        indicator_name = row["Indicator"]
        has_data = row["has_data"]
        
        # Create columns for checkbox and data
        cols = st.columns([0.5, 2] + [1] * len(sample_cols[:5]))
        
        with cols[0]:
            if has_data:
                checked = st.checkbox("Select", key=f"{key_prefix}_{idx}", label_visibility="collapsed")
                if checked:
                    selected_indicators.append(indicator_name)
            else:
                st.checkbox("Select", key=f"{key_prefix}_{idx}", disabled=True, label_visibility="collapsed")
        
        with cols[1]:
            if has_data:
                st.markdown(f"**{indicator_name}**")
            else:
                st.markdown(f"~~{indicator_name}~~ *(No data)*")
        
        for i, col in enumerate(sample_cols[:5]):
            with cols[2 + i]:
                st.markdown(row.get(str(col), "-"))
    
    st.markdown("---")
    st.markdown("**Type 'done' or 'add these' to proceed with selected indicators**")
    
    return selected_indicators

def check_done_command(user_input):
    """Check if user typed done/add command."""
    user_lower = user_input.lower().strip()
    return user_lower in ['done', 'add these', 'add them', 'proceed', 'continue', 'ok']
