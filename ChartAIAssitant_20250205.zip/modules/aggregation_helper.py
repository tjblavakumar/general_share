import pandas as pd

def check_aggregation_request(user_input):
    """Check if user wants to create aggregations."""
    keywords = ['aggregat', 'sum', 'combine', 'add up', 'total']
    user_lower = user_input.lower().strip()
    return any(kw in user_lower for kw in keywords)

def compute_aggregations(df, aggregations, period_cols):
    """Compute aggregated values for each aggregation.
    
    Args:
        df: DataFrame with time-series data
        aggregations: List of dicts with 'name' and 'indicators' keys
        period_cols: List of time period column names
    
    Returns:
        DataFrame with aggregated rows
    """
    indicator_col = df.columns[1]
    agg_rows = []
    
    for agg in aggregations:
        agg_name = agg['name']
        indicators = agg['indicators']
        chart_type = agg.get('chart_type', 'line')
        
        # Get data for all indicators in this aggregation
        agg_data = df[df[indicator_col].isin(indicators)]
        
        # Sum across indicators for each time period
        agg_values = {}
        for col in period_cols:
            total = 0
            for indicator in indicators:
                ind_data = agg_data[agg_data[indicator_col] == indicator]
                if len(ind_data) > 0:
                    try:
                        val = ind_data[col].iloc[0]
                        if pd.notna(val) and val != '':
                            total += float(str(val).replace(',', ''))
                    except:
                        pass
            agg_values[col] = total
        
        # Create row for this aggregation
        row = {df.columns[0]: '', indicator_col: agg_name}
        row.update(agg_values)
        agg_rows.append(row)
    
    return pd.DataFrame(agg_rows)

def format_aggregation_summary(aggregations):
    """Format aggregations for confirmation display."""
    lines = ["**Aggregation Summary:**\n"]
    for i, agg in enumerate(aggregations, 1):
        name = agg['name']
        indicators = agg['indicators']
        chart_type = agg.get('chart_type', 'line')
        lines.append(f"{i}. **{name}** ({chart_type})")
        lines.append(f"   - Sum of: {', '.join(indicators)}\n")
    return '\n'.join(lines)
