import boto3
import json
import config
from botocore.exceptions import ClientError, NoCredentialsError

def get_bedrock_client():
    """Initialize AWS Bedrock client using default credential chain."""
    try:
        # Use boto3's default credential chain without specifying profile
        # This will automatically use: environment vars, ~/.aws/credentials, IAM role, etc.
        return boto3.client('bedrock-runtime', region_name=config.AWS_REGION)
    except Exception as e:
        raise Exception(f"Failed to create AWS client: {str(e)}")

def validate_credentials():
    """Validate AWS credentials."""
    try:
        client = get_bedrock_client()
        return True, None
    except NoCredentialsError:
        return False, "No AWS credentials found. Please run 'aws configure' or 'aws sso login'."
    except ClientError as e:
        error_code = e.response['Error']['Code']
        if error_code == 'ExpiredTokenException':
            return False, "AWS credentials have expired. Please run 'aws sso login' to refresh."
        elif error_code == 'UnrecognizedClientException':
            return False, "Invalid AWS credentials. Please check your AWS configuration."
        else:
            return False, f"AWS error: {error_code}"
    except Exception as e:
        return False, f"Error validating credentials: {str(e)}"

def parse_chart_request_with_sql(user_prompt, table_name, columns, indicator_col):
    """Parse user request and generate SQL query to find relevant indicators."""
    client = get_bedrock_client()
    
    system_prompt = f"""You are a SQL expert. Generate a SQL query to find relevant data indicators.

Table: {table_name}
Columns: {columns}
Indicator column: {indicator_col} (contains descriptions like "Insurance goods", "Personal consumption", etc.)

User wants: {user_prompt}

Return ONLY JSON:
{{
    "sql_query": "SELECT {indicator_col} FROM {table_name} WHERE {indicator_col} LIKE '%keyword%' LIMIT 20",
    "chart_type": "line|bar|pie|stacked_bar",
    "reasoning": "explanation"
}}

Rules:
- Use LIKE with % wildcards for flexible matching
- Extract keywords from user prompt (e.g., "insurance" from "insurance goods")
- Use OR for multiple keywords
- Chart type from user request or default to "line"
- Limit to 20 results"""

    messages = [{"role": "user", "content": user_prompt}]
    
    body = json.dumps({
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 1000,
        "system": system_prompt,
        "messages": messages,
        "temperature": 0.3
    })
    
    try:
        response = client.invoke_model(modelId=config.MODEL_ID, body=body)
        response_body = json.loads(response['body'].read())
        content = response_body['content'][0]['text']
        
        if '```json' in content:
            content = content.split('```json')[1].split('```')[0].strip()
        elif '```' in content:
            content = content.split('```')[1].split('```')[0].strip()
        return json.loads(content)
    except Exception as e:
        # Fallback: simple keyword extraction
        keywords = [w for w in user_prompt.lower().split() if len(w) > 3]
        where_clause = " OR ".join([f"{indicator_col} LIKE '%{kw}%'" for kw in keywords[:3]])
        return {
            "sql_query": f"SELECT {indicator_col} FROM {table_name} WHERE {where_clause} LIMIT 20",
            "chart_type": "line",
            "reasoning": "Keyword-based fallback"
        }

def present_options_with_indicators(user_prompt, indicators, time_periods, chart_type):
    """Present filtered indicators and options to user."""
    msg = f"I found **{len(indicators)}** relevant indicators for your request:\n\n"
    for i, ind in enumerate(indicators[:20], 1):
        msg += f"{i}. {ind}\n"
    if len(indicators) > 20:
        msg += f"\n... and {len(indicators) - 20} more\n"
    
    msg += f"\n**Available time periods:** {', '.join(time_periods[:10])}"
    if len(time_periods) > 10:
        msg += f" ... and {len(time_periods) - 10} more"
    
    msg += f"\n\n**Suggested chart type:** {chart_type}\n"
    msg += "\n**Please specify:**\n"
    msg += "- Which indicators (by number or name)\n"
    msg += "- Time periods (or 'all')\n"
    msg += "- Chart type (line, bar, pie, stacked_bar)\n"
    msg += "- Any customizations (colors, title, etc.)\n"
    
    return msg

def parse_user_selection(user_input, data_info):
    """Parse user's selection and create chart config."""
    client = get_bedrock_client()
    
    system_prompt = f"""Parse user's chart customization choices.

Available:
- Indicators: {data_info['indicators']}
- Time periods: {data_info['time_periods']}

User can specify indicators by:
- Number (e.g., "1, 2, 3")
- Name (e.g., "Insurance goods")
- Keywords (e.g., "all insurance")

Return ONLY JSON:
{{
    "selected_indicators": ["exact indicator names"],
    "selected_periods": ["period names"] or "all",
    "chart_type": "line|bar|pie|stacked_bar",
    "palette": "default|professional|vibrant|pastel",
    "title": "chart title" or null,
    "show_legend": true|false,
    "x_label": "Time Period",
    "y_label": "Value"
}}

Rules:
- If user says "all" or doesn't specify, include ALL indicators from the list
- Match indicator numbers to names from the list
- Extract exact names when mentioned
- Default to "all" periods if not specified
- Infer chart type from context or use what was suggested
- Default palette to "default" unless user specifies
- ALWAYS set x_label to "Time Period" and y_label to "Value"""

    messages = [{"role": "user", "content": user_input}]
    
    body = json.dumps({
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 1000,
        "system": system_prompt,
        "messages": messages,
        "temperature": 0.3
    })
    
    try:
        response = client.invoke_model(modelId=config.MODEL_ID, body=body)
        response_body = json.loads(response['body'].read())
        content = response_body['content'][0]['text']
        
        if '```json' in content:
            content = content.split('```json')[1].split('```')[0].strip()
        elif '```' in content:
            content = content.split('```')[1].split('```')[0].strip()
        result = json.loads(content)
        
        # Ensure labels are set
        if not result.get('x_label'):
            result['x_label'] = 'Time Period'
        if not result.get('y_label'):
            result['y_label'] = 'Value'
        if not result.get('palette'):
            result['palette'] = 'default'
        
        return result
    except Exception as e:
        return None

def generate_confirmation_message(selection):
    """Generate confirmation summary."""
    from modules import color_palette
    
    msg = "**Please confirm your chart configuration:**\n\n"
    msg += f"- **Chart Type:** {selection['chart_type']}\n"
    msg += f"- **Indicators ({len(selection['selected_indicators'])}):** {', '.join([str(i) for i in selection['selected_indicators'][:5]])}{'...' if len(selection['selected_indicators']) > 5 else ''}\n"
    msg += f"- **Time Periods:** {selection['selected_periods'] if isinstance(selection['selected_periods'], str) else ', '.join([str(p) for p in selection['selected_periods'][:5]]) + '...' if len(selection['selected_periods']) > 5 else ', '.join([str(p) for p in selection['selected_periods']])}\n"
    
    # Show color palette
    num_indicators = len(selection['selected_indicators'])
    colors = color_palette.get_colors_for_indicators(num_indicators)
    msg += f"- **Colors:** "
    for color in colors[:10]:
        msg += f'`{color}` '
    if num_indicators > 10:
        msg += "..."
    msg += "\n"
    
    if selection.get('title'):
        msg += f"- **Title:** {selection['title']}\n"
    msg += f"- **Legend:** {'Shown' if selection.get('show_legend', True) else 'Hidden'}\n"
    msg += "\nType 'yes' or 'confirm' to generate the chart, or provide changes."
    return msg

def generate_chart_sql_info(df, selection):
    """Generate SQL query info for debugging."""
    indicator_col = df.columns[1]
    indicators_str = "', '".join([str(i) for i in selection['selected_indicators']])
    
    if selection['selected_periods'] == 'all':
        period_cols = ', '.join([f'"{col}"' for col in df.columns[2:]])
    else:
        period_cols = ', '.join([f'"{col}"' for col in selection['selected_periods']])
    
    sql = f"""SELECT "{indicator_col}", {period_cols}
FROM data_table
WHERE "{indicator_col}" IN ('{indicators_str}')"""
    
    return f"\n\n**SQL Query:**\n```sql\n{sql}\n```"

def check_confirmation(user_input):
    """Check if user confirmed."""
    user_input = user_input.lower().strip()
    return user_input in ['yes', 'confirm', 'ok', 'proceed', 'generate', 'create']
