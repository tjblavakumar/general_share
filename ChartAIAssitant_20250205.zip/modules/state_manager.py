import sqlite3
from datetime import datetime
import config
import pandas as pd

def init_db():
    """Initialize SQLite database for logging."""
    conn = sqlite3.connect(config.DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS chat_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT,
            filename TEXT,
            user_prompt TEXT,
            llm_response TEXT,
            chart_config TEXT
        )
    """)
    conn.commit()
    conn.close()

def log_interaction(filename, user_prompt, llm_response, chart_config):
    """Log user interaction to database."""
    conn = sqlite3.connect(config.DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO chat_logs (timestamp, filename, user_prompt, llm_response, chart_config)
        VALUES (?, ?, ?, ?, ?)
    """, (datetime.now().isoformat(), filename, user_prompt, llm_response, str(chart_config)))
    conn.commit()
    conn.close()

def load_data_to_db(df, filename):
    """Load DataFrame into SQLite for querying."""
    conn = sqlite3.connect(config.DB_PATH)
    table_name = f"data_{filename.replace('.', '_').replace('-', '_')}"
    df.to_sql(table_name, conn, if_exists='replace', index=False)
    conn.commit()
    conn.close()
    return table_name

def query_data(table_name, sql_query):
    """Execute SQL query and return results."""
    conn = sqlite3.connect(config.DB_PATH)
    result = pd.read_sql_query(sql_query, conn)
    conn.close()
    return result

def get_table_schema(table_name):
    """Get column names and sample data from table."""
    conn = sqlite3.connect(config.DB_PATH)
    cursor = conn.cursor()
    cursor.execute(f"PRAGMA table_info({table_name})")
    columns = [row[1] for row in cursor.fetchall()]
    cursor.execute(f"SELECT * FROM {table_name} LIMIT 5")
    sample = cursor.fetchall()
    conn.close()
    return columns, sample
