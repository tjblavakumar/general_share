import os
import pandas as pd
from pathlib import Path
import config

def discover_files():
    """Scan data folder for CSV and XLSX files."""
    data_path = Path(config.DATA_FOLDER)
    if not data_path.exists():
        data_path.mkdir(parents=True)
        return []
    
    files = list(data_path.glob("*.csv")) + list(data_path.glob("*.xlsx"))
    return [f.name for f in files]

def load_file(filename):
    """Load CSV or XLSX file into DataFrame."""
    filepath = Path(config.DATA_FOLDER) / filename
    
    if filename.endswith('.csv'):
        return pd.read_csv(filepath)
    elif filename.endswith('.xlsx'):
        return pd.read_excel(filepath)
    else:
        raise ValueError(f"Unsupported file type: {filename}")

def get_data_summary(df):
    """Generate summary of DataFrame columns and types."""
    summary = {
        "columns": list(df.columns),
        "dtypes": {col: str(dtype) for col, dtype in df.dtypes.items()},
        "shape": df.shape,
        "sample": df.head(3).to_dict(orient='records')
    }
    return summary

def get_timeseries_info(df):
    """Extract indicators and time periods from time-series data structure."""
    # Assuming column 2 (index 1) contains indicators
    # Columns 3+ contain time periods
    indicators = df.iloc[:, 1].dropna().unique().tolist()
    time_periods = df.columns[2:].tolist()  # Columns from index 2 onwards
    
    return {
        "indicators": indicators,
        "time_periods": time_periods,
        "indicator_column": df.columns[1],
        "first_column": df.columns[0]
    }
