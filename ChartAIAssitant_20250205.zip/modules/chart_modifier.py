# Chart modification and history management

def parse_modification_request(user_input, current_config):
    """Parse user's modification request using LLM."""
    from modules import llm_service
    import json
    
    client = llm_service.get_bedrock_client()
    import config
    
    system_prompt = f"""Parse user's chart modification request and extract the exact value.

Current chart config: {json.dumps(current_config, indent=2)}

Return ONLY JSON:
{{
    "modification_type": "line_thickness|color|marker_size|title|axis_label|legend|chart_type|mixed_chart|add_indicator|remove_indicator|time_period|unsupported",
    "target": "all|indicator_name|x|y",
    "value": "extracted_value",
    "indicator_types": {{"indicator1": "line", "indicator2": "bar"}},
    "needs_clarification": true|false,
    "clarification_message": "message",
    "alternative_suggestions": ["suggestion1"]
}}

Modification types:
- title: Change chart title - EXTRACT the full new title text from user input
- line_thickness: Change line width (value: 1-10)
- color: Change color (value: color name or hex)
- marker_size: Change marker size (value: 4-20)
- axis_label: Change axis label (target: x or y, value: new label)
- legend: Show/hide/move (value: show|hide|top|bottom|left|right)
- chart_type: Change type for ALL indicators (value: line|bar|stacked_bar)
- mixed_chart: Different chart types for different indicators (use indicator_types field)
- add_indicator: Add indicator
- remove_indicator: Remove indicator
- time_period: Change period range
- unsupported: Not supported

EXAMPLES:
User: "change title to Sales Report" -> {{"modification_type": "title", "value": "Sales Report"}}
User: "make Foreign autos bar and domestic autos line" -> {{"modification_type": "mixed_chart", "indicator_types": {{"New Foreign autos": "bar", "New domestic autos": "line"}}}}
User: "convert indicator1 to bar and indicator2 to line" -> {{"modification_type": "mixed_chart", "indicator_types": {{"indicator1": "bar", "indicator2": "line"}}}}
User: "make lines thicker" -> {{"modification_type": "line_thickness", "value": "5"}}
User: "change to red" -> {{"modification_type": "color", "target": "all", "value": "red"}}

Rules:
- ALWAYS extract the exact value from user input
- For mixed charts, extract indicator names and their chart types
- Match indicator names from current config
- Be specific with values
"""

    messages = [{"role": "user", "content": user_input}]
    
    body = json.dumps({
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 1000,
        "system": system_prompt,
        "messages": messages,
        "temperature": 0.3
    })
    
    try:
        response = client.invoke_model(modelId=config.MODEL_ID, body=body)
        response_body = json.loads(response['body'].read())
        content = response_body['content'][0]['text']
        
        if '```json' in content:
            content = content.split('```json')[1].split('```')[0].strip()
        elif '```' in content:
            content = content.split('```')[1].split('```')[0].strip()
        return json.loads(content)
    except Exception as e:
        return {
            "modification_type": "unsupported",
            "needs_clarification": False,
            "alternative_suggestions": ["Please try rephrasing your request"]
        }

def apply_modification(config, modification):
    """Apply modification to chart config."""
    new_config = config.copy()
    mod_type = modification['modification_type']
    target = modification.get('target', 'all')
    value = modification.get('value')
    
    if mod_type == 'line_thickness':
        new_config['line_width'] = int(value) if value else 5
    elif mod_type == 'marker_size':
        new_config['marker_size'] = int(value) if value else 10
    elif mod_type == 'color':
        # Convert color name to hex if needed
        color_map = {
            'red': '#FF0000', 'blue': '#0000FF', 'green': '#00FF00',
            'yellow': '#FFFF00', 'orange': '#FFA500', 'purple': '#800080',
            'pink': '#FFC0CB', 'black': '#000000', 'white': '#FFFFFF',
            'gray': '#808080', 'brown': '#A52A2A'
        }
        color_value = color_map.get(value.lower(), value) if value else '#FF0000'
        
        if target == 'all':
            new_config['all_color'] = color_value
        else:
            if 'indicator_colors' not in new_config:
                new_config['indicator_colors'] = {}
            new_config['indicator_colors'][target] = color_value
    elif mod_type == 'title':
        new_config['title'] = value
    elif mod_type == 'axis_label':
        if target == 'x':
            new_config['x_label'] = value
        elif target == 'y':
            new_config['y_label'] = value
    elif mod_type == 'legend':
        if value in ['show', 'hide']:
            new_config['show_legend'] = (value == 'show')
        else:
            new_config['legend_position'] = value
    elif mod_type == 'chart_type':
        new_config['chart_type'] = value
    elif mod_type == 'mixed_chart':
        # Set individual chart types for indicators
        new_config['chart_type'] = 'mixed'
        indicator_types = modification.get('indicator_types', {})
        if 'indicator_chart_types' not in new_config:
            new_config['indicator_chart_types'] = {}
        new_config['indicator_chart_types'].update(indicator_types)
    elif mod_type == 'time_period':
        if isinstance(value, str):
            if ' to ' in value.lower():
                parts = value.lower().split(' to ')
                start_period = parts[0].strip()
                end_period = parts[1].strip() if len(parts) > 1 else None
                new_config['period_range'] = {'start': start_period, 'end': end_period}
            else:
                new_config['selected_periods'] = [value]
        elif isinstance(value, list):
            new_config['selected_periods'] = value
    elif mod_type == 'add_indicator':
        # Add new indicator to the list
        if isinstance(value, list):
            new_config['selected_indicators'] = list(set(new_config.get('selected_indicators', []) + value))
        else:
            current = new_config.get('selected_indicators', [])
            if value not in current:
                new_config['selected_indicators'] = current + [value]
    elif mod_type == 'remove_indicator':
        # Remove indicator from the list
        current = new_config.get('selected_indicators', [])
        if isinstance(value, list):
            new_config['selected_indicators'] = [ind for ind in current if ind not in value]
        else:
            new_config['selected_indicators'] = [ind for ind in current if ind != value]
    
    return new_config

def check_new_chart_request(user_input):
    """Check if user wants to create a new chart."""
    keywords = ['new chart', 'another chart', 'create chart', 'start over', 'new graph', 'different chart']
    user_lower = user_input.lower().strip()
    return any(kw in user_lower for kw in keywords)

def check_undo_request(user_input):
    """Check if user wants to undo."""
    return user_input.lower().strip() in ['undo', 'go back', 'revert']

def check_reset_request(user_input):
    """Check if user wants to reset."""
    return user_input.lower().strip() in ['reset', 'reset chart', 'original']
