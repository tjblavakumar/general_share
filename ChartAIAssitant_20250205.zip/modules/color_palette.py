# Color palettes for chart visualization

DEFAULT_PALETTE = [
    '#004e9a',  # Blue
    '#59ab4e',  # Green
    '#80d2f0',  # Light Blue
    '#ffc700',  # Yellow
]

def get_colors_for_indicators(num_indicators):
    """Get colors for specified number of indicators."""
    colors = []
    for i in range(num_indicators):
        colors.append(DEFAULT_PALETTE[i % len(DEFAULT_PALETTE)])
    return colors
