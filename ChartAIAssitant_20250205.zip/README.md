# Chart AI Assistant

Natural language interface for time-series data visualization using AWS Bedrock and Plotly.

## Setup

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Configure AWS credentials:
```bash
aws configure --profile default
```

3. Create `.env` file (copy from `.env.example`):
```
AWS_REGION=us-east-1
AWS_PROFILE=default
MODEL_ID=anthropic.claude-3-5-sonnet-20241022-v2:0
```

4. Add data files to `/data` folder (CSV or XLSX)

5. Run the app:
```bash
streamlit run app.py
```

## Features

- **Auto-load datasets** from `/data` folder
- **Natural language queries** (e.g., "Show sales as a line chart")
- **Intelligent clarification** when prompts are ambiguous
- **Chart types**: Line, Bar, Pie, Stacked Bar, Mixed (Bar+Line)
- **Manual customization**: Legends, axes, titles
- **SQLite logging** of all interactions

## Example Prompts

- "Generate a line chart for monthly expenses"
- "Show expenses as a line and income as a bar"
- "What data points are available? Suggest some charts"
- "Create a pie chart of category distribution"
