import streamlit as st
from modules import data_loader, llm_service, chart_engine, state_manager, color_palette, chart_modifier, ui_helpers, aggregation_helper, summary_generator
import copy
import pandas as pd

# Initialize
state_manager.init_db()
st.set_page_config(page_title="Chart AI Assistant", layout="wide")

# Validate AWS credentials
is_valid, error_msg = llm_service.validate_credentials()
if not is_valid:
    st.error(f"⚠️ AWS Credentials Error: {error_msg}")
    st.info("""Please update your `.env` file with valid AWS credentials.""")
    st.stop()

# Session state
if 'messages' not in st.session_state:
    st.session_state.messages = [{
        "role": "assistant",
        "content": "Welcome to Chart AI Assistant! I help you build charts based on available data indicators and customize them."
    }]
if 'current_chart_config' not in st.session_state:
    st.session_state.current_chart_config = None
if 'current_df' not in st.session_state:
    st.session_state.current_df = None
if 'conversation_state' not in st.session_state:
    st.session_state.conversation_state = None
if 'data_info' not in st.session_state:
    st.session_state.data_info = None
if 'chart_counter' not in st.session_state:
    st.session_state.chart_counter = 0
if 'modification_history' not in st.session_state:
    st.session_state.modification_history = []
if 'original_chart_config' not in st.session_state:
    st.session_state.original_chart_config = None
if 'in_modification_mode' not in st.session_state:
    st.session_state.in_modification_mode = False
if 'selected_indicators_ui' not in st.session_state:
    st.session_state.selected_indicators_ui = []
if 'aggregation_config' not in st.session_state:
    st.session_state.aggregation_config = None
if 'aggregation_count' not in st.session_state:
    st.session_state.aggregation_count = 0
if 'current_aggregation_index' not in st.session_state:
    st.session_state.current_aggregation_index = 0
if 'aggregations' not in st.session_state:
    st.session_state.aggregations = []

# Sidebar
st.sidebar.title("📁 Data Source")
files = data_loader.discover_files()

if not files:
    st.sidebar.warning("No CSV/XLSX files found in /data folder")
    st.stop()

selected_file = st.sidebar.radio("Select Dataset:", files)

# Load data
if st.session_state.get('selected_file') != selected_file:
    st.session_state.selected_file = selected_file
    st.session_state.current_df = data_loader.load_file(selected_file)
    st.session_state.messages = [{
        "role": "assistant",
        "content": "Welcome to Chart AI Assistant! I help you build charts based on available data indicators and customize them."
    }]
    st.session_state.current_chart_config = None
    st.session_state.conversation_state = None
    st.session_state.data_info = None
    st.session_state.in_modification_mode = False
    st.session_state.modification_history = []
    st.session_state.table_name = state_manager.load_data_to_db(st.session_state.current_df, selected_file)

df = st.session_state.current_df
st.sidebar.success(f"Loaded: {df.shape[0]} rows × {df.shape[1]} cols")

# Helper function to prepare dataframe with aggregations
def prepare_df_with_aggregations(base_df, config):
    """Prepare dataframe with aggregations if present in config."""
    if 'aggregations' in config and config['aggregations']:
        all_periods = base_df.columns[2:].tolist()
        agg_df = aggregation_helper.compute_aggregations(base_df, config['aggregations'], all_periods)
        return pd.concat([base_df, agg_df], ignore_index=True)
    return base_df

# Helper function to display chart with summary
def display_chart_with_summary(fig, chart_df, config):
    """Display chart and generate executive summary."""
    st.plotly_chart(fig, width='stretch')
    
    # Generate and display executive summary
    with st.expander("📊 Executive Summary", expanded=True):
        with st.spinner("Generating insights..."):
            client = llm_service.get_bedrock_client()
            import config as app_config
            summary = summary_generator.generate_executive_summary(
                chart_df, config, client, app_config.MODEL_ID
            )
            st.markdown(summary)
    
    return summary

# Main interface
st.title("🤖 Chart AI Assistant")

# Show modification mode banner
if st.session_state.in_modification_mode and st.session_state.current_chart_config:
    mod_count = len(st.session_state.modification_history)
    st.info(f"✏️ **Chart #{st.session_state.chart_counter}** | {mod_count} modification(s) | Commands: 'undo', 'reset', 'new chart'")

# Chat interface
for idx, msg in enumerate(st.session_state.messages):
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])
        if msg.get("chart"):
            st.plotly_chart(msg["chart"], width='stretch', key=f"chart_{idx}")
            # Display summary if present
            if msg.get("summary"):
                with st.expander("📊 Executive Summary", expanded=False):
                    st.markdown(msg["summary"])
        if msg.get("show_ui"):
            # Re-display checkbox UI
            ts_info = data_loader.get_timeseries_info(df)
            st.session_state.selected_indicators_ui = ui_helpers.display_indicator_selection_ui(
                df, msg["indicators"], ts_info['indicator_column'], key_prefix=msg.get("ui_key", "indicator")
            )

# User input
if prompt := st.chat_input("Ask me to create a chart or modify the current one"):
    st.session_state.messages.append({"role": "user", "content": prompt})
    
    with st.chat_message("user"):
        st.markdown(prompt)
    
    # Handle conversation states
    if st.session_state.conversation_state == 'awaiting_aggregation_count':
        # User specifying how many aggregations
        try:
            count = int(prompt.strip())
            if 1 <= count <= 4:
                st.session_state.aggregation_count = count
                st.session_state.current_aggregation_index = 0
                st.session_state.aggregations = []
                st.session_state.conversation_state = 'awaiting_aggregation_indicators'
                
                with st.chat_message("assistant"):
                    ts_info = data_loader.get_timeseries_info(df)
                    indicator_col = ts_info['indicator_column']
                    indicators = ts_info['indicators'][:50]
                    
                    msg = f"**Aggregation 1 of {count}**: Select indicators to sum and type 'done':"
                    st.markdown(msg)
                    st.session_state.selected_indicators_ui = ui_helpers.display_indicator_selection_ui(
                        df, indicators, indicator_col, key_prefix=f"agg_0"
                    )
                    st.session_state.messages.append({
                        "role": "assistant",
                        "content": msg,
                        "show_ui": True,
                        "indicators": indicators,
                        "ui_key": f"agg_0"
                    })
            else:
                with st.chat_message("assistant"):
                    msg = "Please enter a number between 1 and 4."
                    st.markdown(msg)
                    st.session_state.messages.append({"role": "assistant", "content": msg})
        except:
            with st.chat_message("assistant"):
                msg = "Please enter a valid number (1-4)."
                st.markdown(msg)
                st.session_state.messages.append({"role": "assistant", "content": msg})
    
    elif st.session_state.conversation_state == 'awaiting_aggregation_indicators':
        # User selecting indicators for current aggregation
        if ui_helpers.check_done_command(prompt):
            selected = st.session_state.selected_indicators_ui
            if selected:
                st.session_state.aggregation_config = {'indicators': selected}
                st.session_state.conversation_state = 'awaiting_aggregation_name'
                
                with st.chat_message("assistant"):
                    msg = f"Selected {len(selected)} indicators. What name for this aggregation? (or press Enter for default)"
                    st.markdown(msg)
                    st.session_state.messages.append({"role": "assistant", "content": msg})
            else:
                with st.chat_message("assistant"):
                    msg = "No indicators selected. Please select at least one."
                    st.markdown(msg)
                    st.session_state.messages.append({"role": "assistant", "content": msg})
        else:
            with st.chat_message("assistant"):
                msg = "Please select indicators and type 'done'."
                st.markdown(msg)
                st.session_state.messages.append({"role": "assistant", "content": msg})
    
    elif st.session_state.conversation_state == 'awaiting_aggregation_name':
        # User providing name for aggregation
        agg_name = prompt.strip() if prompt.strip() else f"Sum of {len(st.session_state.aggregation_config['indicators'])} indicators"
        st.session_state.aggregation_config['name'] = agg_name
        st.session_state.conversation_state = 'awaiting_aggregation_chart_type'
        
        with st.chat_message("assistant"):
            msg = f"Chart type for '{agg_name}'? (line/bar, default: line)"
            st.markdown(msg)
            st.session_state.messages.append({"role": "assistant", "content": msg})
    
    elif st.session_state.conversation_state == 'awaiting_aggregation_chart_type':
        # User specifying chart type for aggregation
        chart_type = prompt.strip().lower() if prompt.strip().lower() in ['line', 'bar'] else 'line'
        st.session_state.aggregation_config['chart_type'] = chart_type
        st.session_state.aggregations.append(st.session_state.aggregation_config.copy())
        st.session_state.current_aggregation_index += 1
        
        if st.session_state.current_aggregation_index < st.session_state.aggregation_count:
            # More aggregations to configure
            st.session_state.conversation_state = 'awaiting_aggregation_indicators'
            
            with st.chat_message("assistant"):
                ts_info = data_loader.get_timeseries_info(df)
                indicator_col = ts_info['indicator_column']
                indicators = ts_info['indicators'][:50]
                
                idx = st.session_state.current_aggregation_index
                msg = f"**Aggregation {idx + 1} of {st.session_state.aggregation_count}**: Select indicators and type 'done':"
                st.markdown(msg)
                st.session_state.selected_indicators_ui = ui_helpers.display_indicator_selection_ui(
                    df, indicators, indicator_col, key_prefix=f"agg_{idx}"
                )
                st.session_state.messages.append({
                    "role": "assistant",
                    "content": msg,
                    "show_ui": True,
                    "indicators": indicators,
                    "ui_key": f"agg_{idx}"
                })
        else:
            # All aggregations configured, show summary
            st.session_state.conversation_state = 'awaiting_aggregation_confirmation'
            
            with st.chat_message("assistant"):
                summary = aggregation_helper.format_aggregation_summary(st.session_state.aggregations)
                msg = f"{summary}\nType 'confirm' to generate chart or 'cancel' to start over."
                st.markdown(msg)
                st.session_state.messages.append({"role": "assistant", "content": msg})
    
    elif st.session_state.conversation_state == 'awaiting_aggregation_confirmation':
        # User confirming aggregation configuration
        if prompt.strip().lower() == 'confirm':
            with st.chat_message("assistant"):
                # Compute aggregations
                ts_info = data_loader.get_timeseries_info(df)
                period_cols = ts_info['time_periods']
                
                # Filter period columns by default range
                all_periods = df.columns[2:].tolist()
                period_cols_filtered = []
                in_range = False
                for col in all_periods:
                    col_str = str(col).upper()
                    if '2010M01' in col_str:
                        in_range = True
                    if in_range:
                        period_cols_filtered.append(col)
                    if '2025M01' in col_str:
                        break
                
                agg_df = aggregation_helper.compute_aggregations(df, st.session_state.aggregations, period_cols_filtered)
                agg_names = [agg['name'] for agg in st.session_state.aggregations]
                
                if st.session_state.in_modification_mode:
                    # Adding to existing chart
                    combined_df = pd.concat([df, agg_df], ignore_index=True)
                    
                    new_config = st.session_state.current_chart_config.copy()
                    new_config['selected_indicators'] = new_config.get('selected_indicators', []) + agg_names
                    
                    if 'indicator_chart_types' not in new_config:
                        new_config['indicator_chart_types'] = {}
                    for agg in st.session_state.aggregations:
                        new_config['indicator_chart_types'][agg['name']] = agg['chart_type']
                    
                    if new_config.get('chart_type') != 'mixed':
                        new_config['chart_type'] = 'mixed'
                    
                    if 'aggregations' not in new_config:
                        new_config['aggregations'] = []
                    new_config['aggregations'].extend(st.session_state.aggregations)
                    
                    st.session_state.modification_history.append(copy.deepcopy(new_config))
                    st.session_state.current_chart_config = new_config
                    
                    fig = chart_engine.create_timeseries_chart(combined_df, new_config)
                    st.markdown(f"✅ Added {len(agg_names)} aggregation(s)")
                    summary = display_chart_with_summary(fig, combined_df, new_config)
                    st.session_state.messages.append({"role": "assistant", "content": f"✅ Added {len(agg_names)} aggregation(s)", "chart": fig, "summary": summary})
                else:
                    # Creating new chart
                    st.session_state.chart_counter += 1
                    combined_df = pd.concat([df, agg_df], ignore_index=True)
                    
                    config = {
                        'selected_indicators': agg_names,
                        'selected_periods': 'all',
                        'period_range': {'start': '2010m01', 'end': '2025m01'},
                        'chart_type': 'mixed',
                        'indicator_chart_types': {agg['name']: agg['chart_type'] for agg in st.session_state.aggregations},
                        'x_label': 'Time Period',
                        'y_label': 'Value',
                        'show_legend': True,
                        'aggregations': st.session_state.aggregations
                    }
                    
                    fig = chart_engine.create_timeseries_chart(combined_df, config)
                    st.markdown(f"✅ Chart #{st.session_state.chart_counter} with {len(agg_names)} aggregation(s) generated!")
                    summary = display_chart_with_summary(fig, combined_df, config)
                    st.session_state.messages.append({"role": "assistant", "content": f"✅ Chart #{st.session_state.chart_counter} generated!", "chart": fig, "summary": summary})
                    
                    st.session_state.current_chart_config = copy.deepcopy(config)
                    st.session_state.original_chart_config = copy.deepcopy(config)
                    st.session_state.in_modification_mode = True
                
                st.session_state.conversation_state = None
                st.session_state.aggregations = []
            st.rerun()
        elif prompt.strip().lower() == 'cancel':
            st.session_state.conversation_state = None
            st.session_state.aggregations = []
            with st.chat_message("assistant"):
                msg = "Cancelled. What would you like to do?"
                st.markdown(msg)
                st.session_state.messages.append({"role": "assistant", "content": msg})
        else:
            with st.chat_message("assistant"):
                msg = "Please type 'confirm' or 'cancel'."
                st.markdown(msg)
                st.session_state.messages.append({"role": "assistant", "content": msg})
    
    elif st.session_state.conversation_state == 'awaiting_done_command':
        # User selecting indicators via checkboxes
        if ui_helpers.check_done_command(prompt):
            selected = st.session_state.selected_indicators_ui
            if selected:
                with st.chat_message("assistant"):
                    if st.session_state.in_modification_mode:
                        # Adding to existing chart
                        modification = {'modification_type': 'add_indicator', 'value': selected}
                        new_config = chart_modifier.apply_modification(st.session_state.current_chart_config, modification)
                        st.session_state.modification_history.append(copy.deepcopy(new_config))
                        st.session_state.current_chart_config = new_config
                        
                        chart_df = prepare_df_with_aggregations(df, new_config)
                        fig = chart_engine.create_timeseries_chart(chart_df, new_config)
                        st.markdown(f"✅ Added {len(selected)} indicator(s)")
                        summary = display_chart_with_summary(fig, chart_df, new_config)
                        st.session_state.messages.append({"role": "assistant", "content": f"✅ Added {len(selected)} indicator(s)", "chart": fig, "summary": summary})
                    else:
                        # Creating new chart
                        st.session_state.chart_counter += 1
                        config = {
                            'selected_indicators': selected,
                            'selected_periods': 'all',
                            'period_range': {'start': '2010m01', 'end': '2025m01'},
                            'chart_type': st.session_state.data_info.get('chart_type', 'line'),
                            'x_label': 'Time Period',
                            'y_label': 'Value',
                            'show_legend': True
                        }
                        
                        fig = chart_engine.create_timeseries_chart(df, config)
                        st.markdown(f"✅ Chart #{st.session_state.chart_counter} generated!")
                        summary = display_chart_with_summary(fig, df, config)
                        st.session_state.messages.append({"role": "assistant", "content": f"✅ Chart #{st.session_state.chart_counter} generated!", "chart": fig, "summary": summary})
                        
                        st.session_state.current_chart_config = copy.deepcopy(config)
                        st.session_state.original_chart_config = copy.deepcopy(config)
                        st.session_state.in_modification_mode = True
                    
                    st.session_state.conversation_state = None
                st.rerun()
            else:
                with st.chat_message("assistant"):
                    msg = "No indicators selected. Please select at least one using the checkboxes above."
                    st.markdown(msg)
                    st.session_state.messages.append({"role": "assistant", "content": msg})
        else:
            with st.chat_message("assistant"):
                msg = "Please select indicators using checkboxes above, then type 'done' or 'add these'"
                st.markdown(msg)
                st.session_state.messages.append({"role": "assistant", "content": msg})
    
    elif st.session_state.in_modification_mode:
        # In modification mode
        if chart_modifier.check_new_chart_request(prompt):
            st.session_state.in_modification_mode = False
            st.session_state.modification_history = []
            st.session_state.original_chart_config = None
            st.session_state.conversation_state = None
            with st.chat_message("assistant"):
                msg = "Starting new chart. What would you like to visualize?"
                st.markdown(msg)
                st.session_state.messages.append({"role": "assistant", "content": msg})
            st.rerun()
        
        elif chart_modifier.check_undo_request(prompt):
            if len(st.session_state.modification_history) > 0:
                st.session_state.modification_history.pop()
                st.session_state.current_chart_config = copy.deepcopy(
                    st.session_state.modification_history[-1] if st.session_state.modification_history 
                    else st.session_state.original_chart_config
                )
                with st.chat_message("assistant"):
                    chart_df = prepare_df_with_aggregations(df, st.session_state.current_chart_config)
                    fig = chart_engine.create_timeseries_chart(chart_df, st.session_state.current_chart_config)
                    st.markdown("↩️ Undone last modification")
                    summary = display_chart_with_summary(fig, chart_df, st.session_state.current_chart_config)
                    st.session_state.messages.append({"role": "assistant", "content": "↩️ Undone last modification", "chart": fig, "summary": summary})
            else:
                with st.chat_message("assistant"):
                    msg = "No modifications to undo."
                    st.markdown(msg)
                    st.session_state.messages.append({"role": "assistant", "content": msg})
            st.rerun()
        
        elif chart_modifier.check_reset_request(prompt):
            mod_count = len(st.session_state.modification_history)
            with st.chat_message("assistant"):
                if mod_count > 0:
                    st.session_state.current_chart_config = copy.deepcopy(st.session_state.original_chart_config)
                    st.session_state.modification_history = []
                    chart_df = prepare_df_with_aggregations(df, st.session_state.current_chart_config)
                    fig = chart_engine.create_timeseries_chart(chart_df, st.session_state.current_chart_config)
                    st.markdown(f"🔄 Reset Chart #{st.session_state.chart_counter} to original")
                    summary = display_chart_with_summary(fig, chart_df, st.session_state.current_chart_config)
                    st.session_state.messages.append({"role": "assistant", "content": f"🔄 Reset to original", "chart": fig, "summary": summary})
                else:
                    msg = "Chart is already in original state."
                    st.markdown(msg)
                    st.session_state.messages.append({"role": "assistant", "content": msg})
            st.rerun()
        
        else:
            # Handle modification
            # Check if user wants to add aggregation
            if aggregation_helper.check_aggregation_request(prompt):
                with st.chat_message("assistant"):
                    msg = "How many aggregations do you want to add? (1-4)"
                    st.markdown(msg)
                    st.session_state.messages.append({"role": "assistant", "content": msg})
                    st.session_state.conversation_state = 'awaiting_aggregation_count'
            else:
                with st.chat_message("assistant"):
                    modification = chart_modifier.parse_modification_request(prompt, st.session_state.current_chart_config)
                
                if modification['modification_type'] == 'unsupported':
                    msg = "❌ Not supported.\n" + "\n".join(modification.get('alternative_suggestions', []))
                    st.markdown(msg)
                    st.session_state.messages.append({"role": "assistant", "content": msg})
                
                elif modification.get('needs_clarification'):
                    msg = modification.get('clarification_message', 'Please clarify.')
                    st.markdown(msg)
                    st.session_state.messages.append({"role": "assistant", "content": msg})
                
                elif modification['modification_type'] == 'add_indicator':
                    ts_info = data_loader.get_timeseries_info(df)
                    indicator_col = ts_info['indicator_column']
                    
                    sql_result = llm_service.parse_chart_request_with_sql(prompt, st.session_state.table_name, list(df.columns), indicator_col)
                    
                    try:
                        query_result = state_manager.query_data(st.session_state.table_name, sql_result['sql_query'])
                        relevant_indicators = query_result[indicator_col].dropna().unique().tolist()
                    except:
                        keywords = [w for w in prompt.lower().split() if len(w) > 3]
                        relevant_indicators = [ind for ind in ts_info['indicators'] if any(kw in str(ind).lower() for kw in keywords)][:20]
                    
                    if relevant_indicators:
                        st.markdown(f"Found {len(relevant_indicators)} matching indicators. Select and type 'done':")
                        st.session_state.selected_indicators_ui = ui_helpers.display_indicator_selection_ui(
                            df, relevant_indicators, indicator_col, key_prefix="add"
                        )
                        st.session_state.messages.append({
                            "role": "assistant", 
                            "content": f"Select indicators and type 'done':",
                            "show_ui": True,
                            "indicators": relevant_indicators,
                            "ui_key": "add"
                        })
                        st.session_state.conversation_state = 'awaiting_done_command'
                    else:
                        st.markdown("No matching indicators found.")
                        st.session_state.messages.append({"role": "assistant", "content": "No matching indicators found."})
                
                else:
                    new_config = chart_modifier.apply_modification(st.session_state.current_chart_config, modification)
                    st.session_state.modification_history.append(copy.deepcopy(new_config))
                    st.session_state.current_chart_config = new_config
                    
                    chart_df = prepare_df_with_aggregations(df, new_config)
                    fig = chart_engine.create_timeseries_chart(chart_df, new_config)
                    st.markdown(f"✅ Modified: {modification['modification_type'].replace('_', ' ')}")
                    summary = display_chart_with_summary(fig, chart_df, new_config)
                    st.session_state.messages.append({"role": "assistant", "content": f"✅ Modified", "chart": fig, "summary": summary})
            st.rerun()
    
    else:
        # Initial chart request
        # Check if user wants aggregation
        if aggregation_helper.check_aggregation_request(prompt):
            with st.chat_message("assistant"):
                msg = "How many aggregations do you want to create? (1-4)"
                st.markdown(msg)
                st.session_state.messages.append({"role": "assistant", "content": msg})
                st.session_state.conversation_state = 'awaiting_aggregation_count'
        else:
            with st.chat_message("assistant"):
                ts_info = data_loader.get_timeseries_info(df)
                indicator_col = ts_info['indicator_column']
                
                sql_result = llm_service.parse_chart_request_with_sql(prompt, st.session_state.table_name, list(df.columns), indicator_col)
                
                try:
                    query_result = state_manager.query_data(st.session_state.table_name, sql_result['sql_query'])
                    relevant_indicators = query_result[indicator_col].dropna().unique().tolist()
                except:
                    keywords = [w for w in prompt.lower().split() if len(w) > 3]
                    relevant_indicators = [ind for ind in ts_info['indicators'] if any(kw in str(ind).lower() for kw in keywords)][:20]
                
                if not relevant_indicators:
                    relevant_indicators = ts_info['indicators'][:20]
                
                st.session_state.data_info = {
                    'indicators': relevant_indicators,
                    'time_periods': ts_info['time_periods'],
                    'chart_type': sql_result.get('chart_type', 'line')
                }
                
                st.markdown(f"Found {len(relevant_indicators)} relevant indicators. Select and type 'done':")
                st.session_state.selected_indicators_ui = ui_helpers.display_indicator_selection_ui(
                    df, relevant_indicators, indicator_col, key_prefix="initial"
                )
                st.session_state.messages.append({
                    "role": "assistant",
                    "content": f"Select indicators and type 'done':",
                    "show_ui": True,
                    "indicators": relevant_indicators,
                    "ui_key": "initial"
                })
                st.session_state.conversation_state = 'awaiting_done_command'
