# AI/GenAI Security Review

A web application for managing information security reviews of AI and Generative AI projects. Organizations can use this tool to ensure AI/GenAI projects meet security, privacy, and compliance requirements through a structured questionnaire and review workflow.

## Architecture Overview

```mermaid
graph TB
    subgraph Frontend["Frontend (Next.js 14)"]
        UI[React UI with shadcn/ui]
        API_CLIENT[API Client]
    end
    
    subgraph Backend["Backend (FastAPI)"]
        ROUTES[API Routers]
        SERVICES[Service Layer]
        MODELS[SQLAlchemy Models]
    end
    
    subgraph Database["Database"]
        SQLITE[(SQLite)]
    end
    
    UI --> API_CLIENT
    API_CLIENT -->|REST API| ROUTES
    ROUTES --> SERVICES
    SERVICES --> MODELS
    MODELS --> SQLITE
```

### Workflow

```mermaid
stateDiagram-v2
    [*] --> Draft: Create Submission
    Draft --> Submitted: Submit for Review
    Submitted --> Approved: Reviewer Approves
    Submitted --> Returned: Reviewer Returns
    Returned --> Submitted: Resubmit
    Approved --> [*]
```

## Tech Stack

| Layer      | Technology                                 |
|------------|--------------------------------------------|
| Frontend   | Next.js 14 (App Router), TypeScript, Tailwind CSS, shadcn/ui |
| Backend    | Python 3.11+, FastAPI, SQLAlchemy 2.0, Pydantic v2 |
| Database   | SQLite (via SQLAlchemy)                    |
| State Mgmt | Zustand                                    |
| Icons      | Lucide React                               |
| Container  | Docker + Docker Compose                    |

## Prerequisites

- **Python 3.11+**
- **Node.js 20+**
- **Docker & Docker Compose** (optional, for containerized setup)
- **OpenAI API Key** (Phase 2 — not required for Phase 1)

## Quick Start

### Option 1: Docker Compose (Recommended)

```bash
# Clone the repository
git clone https://github.com/atakkallapalli/ai-security-review.git
cd ai-security-review

# Start all services
docker-compose up --build

# Frontend: http://localhost:3000
# Backend:  http://localhost:8000
# API Docs: http://localhost:8000/docs
```

### Option 2: Manual Setup

#### Backend

```bash
cd backend

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Copy environment file
cp .env.example .env

# Run the server (auto-seeds database on first start)
uvicorn app.main:app --reload --port 8000
```

#### Frontend

```bash
cd frontend

# Install dependencies
npm install

# Run the dev server
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

## Project Structure

```
ai-security-review/
├── backend/
│   ├── app/
│   │   ├── main.py              # FastAPI application entry point
│   │   ├── config.py            # Settings via pydantic-settings
│   │   ├── database.py          # SQLAlchemy engine & session
│   │   ├── models/
│   │   │   └── models.py        # SQLAlchemy ORM models (14 models)
│   │   ├── schemas/
│   │   │   └── schemas.py       # Pydantic request/response schemas
│   │   ├── routers/
│   │   │   ├── questions.py     # CRUD endpoints for questions & categories
│   │   │   ├── submissions.py   # Submission lifecycle endpoints
│   │   │   ├── reviews.py       # Review workflow endpoints
│   │   │   └── notifications.py # Notification endpoints
│   │   └── services/
│   │       ├── question_service.py     # Question business logic
│   │       ├── submission_service.py   # Submission business logic
│   │       ├── review_service.py       # Review business logic
│   │       └── notification_service.py # Notification business logic
│   ├── seed_data.py             # Database seeding script
│   ├── requirements.txt
│   ├── Dockerfile
│   └── .env.example
├── frontend/
│   ├── src/
│   │   ├── app/
│   │   │   ├── layout.tsx       # Root layout with navigation
│   │   │   ├── page.tsx         # Landing page
│   │   │   ├── submit/          # Submission wizard pages
│   │   │   ├── my-submissions/  # Submission tracking
│   │   │   └── admin/           # Admin dashboard & management
│   │   ├── components/ui/       # shadcn/ui components
│   │   └── lib/
│   │       ├── api.ts           # API client wrapper
│   │       ├── types.ts         # TypeScript interfaces
│   │       └── utils.ts         # Utility functions
│   ├── Dockerfile
│   └── package.json
├── docker-compose.yml
├── .env
├── .gitignore
└── README.md
```

## Database Models

The application includes 14 SQLAlchemy models:

| Model                 | Description                                    |
|-----------------------|------------------------------------------------|
| QuestionCategory      | Groups questions into logical sections          |
| Question              | Individual questionnaire items                  |
| QuestionCondition     | Conditional display rules between questions     |
| QuestionPolicyLink    | Links questions to policy documents             |
| QuestionnaireVersion  | Version tracking for questionnaire updates      |
| Submission            | Project submission with metadata                |
| SubmissionResponse    | Individual answers to questions                 |
| SubmissionAttachment  | File uploads associated with submissions        |
| Review                | Reviewer decisions (approve/return)             |
| ReviewComment         | Per-question review comments                    |
| PolicyDocument        | Reference policy documents                      |
| DocumentTag           | Tags associated with policy documents           |
| MasterTag             | Centralized tag definitions                     |
| Notification          | In-app notification records                     |

## API Endpoints

### Questions
- `GET /api/questions` — List all questions
- `POST /api/questions` — Create a question
- `GET /api/questions/{id}` — Get question by ID
- `PUT /api/questions/{id}` — Update a question
- `DELETE /api/questions/{id}` — Delete a question
- `PATCH /api/questions/reorder` — Reorder questions
- `GET /api/questions/categories` — List categories
- `POST /api/questions/categories` — Create a category
- `GET /api/questions/preview` — Get questions in submitter-facing order

### Submissions
- `GET /api/submissions` — List submissions (filter by email)
- `POST /api/submissions` — Create a submission
- `GET /api/submissions/{id}` — Get submission with responses
- `POST /api/submissions/{id}/responses` — Save responses
- `POST /api/submissions/{id}/submit` — Submit for review
- `GET /api/submissions/{id}/progress` — Get progress

### Reviews
- `GET /api/reviews/queue` — Get review queue
- `GET /api/reviews/submission/{id}` — Get submission for review
- `POST /api/reviews/submission/{id}/approve` — Approve submission
- `POST /api/reviews/submission/{id}/return` — Return with comments

### Notifications
- `GET /api/notifications?email=...` — Get notifications
- `PATCH /api/notifications/{id}/read` — Mark as read
- `GET /api/notifications/unread-count?email=...` — Get unread count

## Seed Data

The application automatically seeds the database on first startup with:
- **11 question categories** covering security review domains
- **33 sample questions** across all categories with various types
- **Conditional logic** examples (e.g., PII follow-up questions)

## Phase Roadmap

| Phase | Description                                    | Status      |
|-------|------------------------------------------------|-------------|
| 1     | Core questionnaire, submission & review workflow | Current     |
| 2     | AI-powered suggestions, RAG chat assistant      | Planned     |
| 3     | Advanced conditional logic, drag-and-drop reorder| Planned    |
| 4     | SSO integration, role-based access control      | Planned     |
| 5     | Analytics dashboard, reporting, audit trails    | Planned     |

## License

Internal use only.
