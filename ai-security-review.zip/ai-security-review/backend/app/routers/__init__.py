from app.routers.notifications import router as notifications_router
from app.routers.questions import router as questions_router
from app.routers.reviews import router as reviews_router
from app.routers.submissions import router as submissions_router

__all__ = [
    "questions_router",
    "submissions_router",
    "reviews_router",
    "notifications_router",
]
