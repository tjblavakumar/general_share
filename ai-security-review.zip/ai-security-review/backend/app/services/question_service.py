import json
from typing import Sequence

from sqlalchemy import select
from sqlalchemy.orm import Session, joinedload

from app.models import Question, QuestionCategory, QuestionCondition, SubmissionResponse
from app.schemas import QuestionCategoryCreate, QuestionCreate, QuestionUpdate, ReorderRequest


def list_categories(db: Session) -> Sequence[QuestionCategory]:
    stmt = select(QuestionCategory).order_by(QuestionCategory.display_order)
    return db.scalars(stmt).all()


def create_category(db: Session, data: QuestionCategoryCreate) -> QuestionCategory:
    category = QuestionCategory(**data.model_dump())
    db.add(category)
    db.commit()
    db.refresh(category)
    return category


def list_questions(db: Session, category_id: int | None = None, active_only: bool = False) -> Sequence[Question]:
    stmt = select(Question).options(joinedload(Question.conditions), joinedload(Question.category))
    if category_id is not None:
        stmt = stmt.where(Question.category_id == category_id)
    if active_only:
        stmt = stmt.where(Question.is_active.is_(True))
    stmt = stmt.order_by(Question.display_order)
    return db.scalars(stmt).unique().all()


def get_question(db: Session, question_id: int) -> Question | None:
    stmt = select(Question).options(joinedload(Question.conditions), joinedload(Question.category)).where(Question.id == question_id)
    return db.scalars(stmt).first()


def create_question(db: Session, data: QuestionCreate) -> Question:
    question = Question(**data.model_dump())
    db.add(question)
    db.commit()
    db.refresh(question)
    return question


def update_question(db: Session, question_id: int, data: QuestionUpdate) -> Question | None:
    question = db.get(Question, question_id)
    if question is None:
        return None
    update_data = data.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(question, key, value)
    db.commit()
    db.refresh(question)
    return question


def delete_question(db: Session, question_id: int) -> bool:
    question = db.get(Question, question_id)
    if question is None:
        return False
    db.delete(question)
    db.commit()
    return True


def reorder_questions(db: Session, data: ReorderRequest) -> bool:
    for item in data.items:
        question = db.get(Question, item.id)
        if question is not None:
            question.display_order = item.display_order
    db.commit()
    return True


def get_preview_questions(db: Session) -> list[Question]:
    stmt = (
        select(Question)
        .options(joinedload(Question.conditions), joinedload(Question.category))
        .where(Question.is_active.is_(True))
        .order_by(Question.display_order)
    )
    return list(db.scalars(stmt).unique().all())


def evaluate_conditions(question: Question, responses: dict[int, str | None]) -> bool:
    if not question.conditions:
        return True
    for condition in question.conditions:
        answer = responses.get(condition.depends_on_question_id)
        if answer is None:
            return False
        if answer.strip().lower() != condition.expected_value.strip().lower():
            return False
    return True


def get_applicable_questions(db: Session, submission_responses: list[SubmissionResponse]) -> list[Question]:
    all_questions = get_preview_questions(db)
    response_map: dict[int, str | None] = {r.question_id: r.response_value for r in submission_responses}
    applicable: list[Question] = []
    for q in all_questions:
        if evaluate_conditions(q, response_map):
            applicable.append(q)
    return applicable
