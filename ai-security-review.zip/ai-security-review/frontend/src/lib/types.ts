export type QuestionType = "text" | "textarea" | "yes_no" | "single_select" | "multi_select";
export type SubmissionStatus = "draft" | "submitted" | "in_review" | "returned" | "approved";
export type ProjectType = "new" | "modification" | "third-party";
export type NotificationType = "submission_created" | "submission_submitted" | "submission_returned" | "submission_approved";

export interface QuestionCategory {
  id: number;
  name: string;
  description: string | null;
  display_order: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface QuestionCondition {
  id: number;
  question_id: number;
  depends_on_question_id: number;
  expected_value: string;
}

export interface Question {
  id: number;
  category_id: number;
  question_text: string;
  description: string | null;
  question_type: QuestionType;
  options: string | null;
  is_required: boolean;
  is_active: boolean;
  allows_attachment: boolean;
  display_order: number;
  created_at: string;
  updated_at: string;
  conditions: QuestionCondition[];
  category?: QuestionCategory;
}

export interface Submission {
  id: number;
  project_name: string;
  project_description: string | null;
  submitter_name: string;
  submitter_email: string;
  team_department: string | null;
  target_go_live_date: string | null;
  project_type: ProjectType;
  status: SubmissionStatus;
  current_step: number;
  created_at: string;
  updated_at: string;
  submitted_at: string | null;
}

export interface SubmissionResponse {
  id: number;
  submission_id: number;
  question_id: number;
  response_value: string | null;
  is_skipped: boolean;
  created_at: string;
  updated_at: string;
}

export interface SubmissionDetail extends Submission {
  responses: SubmissionResponse[];
}

export interface SubmissionProgress {
  submission_id: number;
  total_questions: number;
  answered_questions: number;
  progress_percent: number;
  current_step: number;
}

export interface Review {
  id: number;
  submission_id: number;
  reviewer_name: string;
  reviewer_email: string;
  overall_comments: string | null;
  decision: string;
  created_at: string;
  comments: ReviewComment[];
}

export interface ReviewComment {
  id: number;
  review_id: number;
  question_id: number;
  comment_text: string;
  created_at: string;
}

export interface Notification {
  id: number;
  recipient_email: string;
  notification_type: NotificationType;
  title: string;
  message: string;
  submission_id: number | null;
  is_read: boolean;
  created_at: string;
}
