"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { api } from "@/lib/api";
import { FileQuestion, ClipboardCheck } from "lucide-react";
import type { Question, Submission } from "@/lib/types";

export default function AdminDashboardPage() {
  const [questionCount, setQuestionCount] = useState(0);
  const [pendingCount, setPendingCount] = useState(0);

  useEffect(() => {
    api.get<Question[]>("/questions").then((res) => setQuestionCount(res.data.length));
    api.get<Submission[]>("/reviews/queue").then((res) => setPendingCount(res.data.length));
  }, []);

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Admin Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader>
            <FileQuestion className="h-8 w-8 text-blue-600 mb-2" />
            <CardTitle>Manage Questions</CardTitle>
            <CardDescription>
              Add, edit, and organize security review questions.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex items-center justify-between">
            <span className="text-2xl font-bold text-gray-700">
              {questionCount} questions
            </span>
            <Link href="/admin/questions">
              <Button>Manage</Button>
            </Link>
          </CardContent>
        </Card>

        <Card className="hover:shadow-lg transition-shadow">
          <CardHeader>
            <ClipboardCheck className="h-8 w-8 text-green-600 mb-2" />
            <CardTitle>Review Submissions</CardTitle>
            <CardDescription>
              Review and approve pending security review submissions.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex items-center justify-between">
            <span className="text-2xl font-bold text-gray-700">
              {pendingCount} pending
            </span>
            <Link href="/admin/submissions">
              <Button variant="outline">Review</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
